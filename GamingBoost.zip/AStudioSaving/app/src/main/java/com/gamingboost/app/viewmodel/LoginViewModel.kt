package com.gamingboost.app.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel

class LoginViewModel : ViewModel() {

    var email = mutableStateOf("")
        private set

    var password = mutableStateOf("")
        private set

    var isLoginEnabled = mutableStateOf(false)
        private set

    fun onEmailChange(newEmail: String) {
        email.value = newEmail
        validateForm()
    }

    fun onPasswordChange(newPassword: String) {
        password.value = newPassword
        validateForm()
    }

    private fun validateForm() {
        isLoginEnabled.value =
            email.value.isNotBlank() &&
                    password.value.length >= 6
    }
}